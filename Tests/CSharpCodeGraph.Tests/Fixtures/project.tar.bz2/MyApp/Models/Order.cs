namespace MyApp.Models;

public class Order
{
    public void Place() { }
}
