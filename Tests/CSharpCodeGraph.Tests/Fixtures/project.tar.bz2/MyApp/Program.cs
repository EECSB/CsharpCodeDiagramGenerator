namespace MyApp;

public class Program
{
    public static void Main() => new Models.Order().Place();
}
